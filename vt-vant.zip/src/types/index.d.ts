export interface Login {
    userName: String
    password: String
}