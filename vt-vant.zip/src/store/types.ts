export default interface State {
	count: number
	token: string
	theme: string
}