import State from "./types";

const state: State = {
  count: 0,
  token: "123123231sfsfwe",
  theme: "dark"
};

export default state;
